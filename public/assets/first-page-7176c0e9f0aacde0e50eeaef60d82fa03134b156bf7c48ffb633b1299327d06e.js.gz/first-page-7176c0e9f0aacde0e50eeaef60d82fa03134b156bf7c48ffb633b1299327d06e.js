$(document).ready(function() {
    
    $(".logo-first-page").hide().fadeIn("slow");
    $(".login-form").animate({
        top: '-=10px',
        opacity: '1'
    }, 800);
});
