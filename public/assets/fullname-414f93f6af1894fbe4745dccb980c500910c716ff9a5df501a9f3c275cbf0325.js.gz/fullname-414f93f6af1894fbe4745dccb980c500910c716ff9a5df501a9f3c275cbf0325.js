function fullname() {
	document.getElementById("fullname").innerHTML="Rangga Garmastweira";
}
;
